# ADS1256
An Arduino-compatible library for the ADS1256 24-bit analog-to-digital converter.

For usage, see the documentation: https://github.com/CuriousScientist0/ADS1256/blob/main/extras/ADS1256_ArduinoLibrary_Documentation.pdf
